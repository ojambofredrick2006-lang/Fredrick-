import React, { useEffect, useRef, useState } from 'react';
import { supabase, isConfigured } from './supabase';
import { Home, Search, PlusSquare, UserRound, Heart, MessageCircle, Share2, Play, LogOut, X, Clapperboard } from 'lucide-react';

const demoVideos = [
  { id: 'demo-1', caption: 'Welcome to FREDRICK! Your next favourite video community starts here. 🚀', username: 'fredrick_official', video_url: '', likes_count: 128, demo: true },
  { id: 'demo-2', caption: 'Create something amazing and share it with the world. 🌍', username: 'creator_one', video_url: '', likes_count: 84, demo: true }
];

export default function App() {
  const [session, setSession] = useState(null);
  const [videos, setVideos] = useState(demoVideos);
  const [tab, setTab] = useState('Home');
  const [authMode, setAuthMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [caption, setCaption] = useState('');
  const [uploadFile, setUploadFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [search, setSearch] = useState('');
  const [liked, setLiked] = useState({});
  const fileRef = useRef(null);

  useEffect(() => {
    if (!isConfigured) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    loadVideos();
    return () => listener.subscription.unsubscribe();
  }, []);

  async function loadVideos() {
    if (!isConfigured) return;
    const { data, error } = await supabase.from('videos').select('id, caption, video_url, created_at, user_id').order('created_at', { ascending: false }).limit(50);
    if (error) { setNotice(error.message); return; }
    setVideos(data?.length ? data.map(v => ({...v, username: 'fredrick_user', likes_count: 0})) : demoVideos);
  }

  async function authenticate(e) {
    e.preventDefault(); setBusy(true); setNotice('');
    if (!isConfigured) { setNotice('Connect your free Supabase project first. Follow SETUP.md in the downloaded folder.'); setBusy(false); return; }
    const action = authMode === 'signup'
      ? supabase.auth.signUp({ email, password })
      : supabase.auth.signInWithPassword({ email, password });
    const { error } = await action;
    setNotice(error ? error.message : (authMode === 'signup' ? 'Account created. Check your email if confirmation is enabled.' : 'Welcome back!'));
    setBusy(false);
  }

  async function uploadVideo(e) {
    e.preventDefault();
    if (!session) { setNotice('Please log in before uploading.'); return; }
    if (!uploadFile) { setNotice('Choose a video first.'); return; }
    if (uploadFile.size > 50 * 1024 * 1024) { setNotice('This starter version allows videos up to 50 MB.'); return; }
    setBusy(true); setNotice('');
    const safeName = `${session.user.id}/${Date.now()}-${uploadFile.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
    const { error: storageError } = await supabase.storage.from('videos').upload(safeName, uploadFile, { upsert: false });
    if (storageError) { setNotice(storageError.message); setBusy(false); return; }
    const { data: urlData } = supabase.storage.from('videos').getPublicUrl(safeName);
    const { error } = await supabase.from('videos').insert({ user_id: session.user.id, caption, video_url: urlData.publicUrl });
    if (error) setNotice(error.message);
    else { setNotice('Your video is live!'); setCaption(''); setUploadFile(null); setTab('Home'); await loadVideos(); }
    setBusy(false);
  }

  async function logout() { await supabase.auth.signOut(); setNotice('You have signed out.'); }
  function toggleLike(id) { setLiked(p => ({...p, [id]: !p[id]})); }

  const filtered = videos.filter(v => `${v.caption || ''} ${v.username || ''}`.toLowerCase().includes(search.toLowerCase()));

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#" onClick={() => setTab('Home')}><span className="brand-mark">F</span><span>FREDRICK</span></a>
      <div className="top-actions"><span className="free-pill">FREE TO JOIN</span>{session ? <button className="avatar" onClick={() => setTab('Profile')}>{(session.user.email || 'F')[0].toUpperCase()}</button> : <button className="login-top" onClick={() => setTab('Account')}>Log in</button>}</div>
    </header>

    <main className="layout">
      <aside className="sidebar">
        <nav>
          <NavButton icon={<Home/>} label="Home" active={tab==='Home'} onClick={()=>setTab('Home')}/>
          <NavButton icon={<Search/>} label="Discover" active={tab==='Discover'} onClick={()=>setTab('Discover')}/>
          <NavButton icon={<PlusSquare/>} label="Upload" active={tab==='Upload'} onClick={()=>setTab('Upload')}/>
          <NavButton icon={<UserRound/>} label="Profile" active={tab==='Profile'} onClick={()=>setTab('Profile')}/>
        </nav>
        <div className="side-note"><Clapperboard size={21}/><b>Your story deserves an audience.</b><p>Watch, create and share with the FREDRICK community.</p></div>
        {session && <button className="logout" onClick={logout}><LogOut size={17}/> Sign out</button>}
      </aside>

      <section className="content">
        {notice && <div className="notice"><span>{notice}</span><button onClick={()=>setNotice('')}><X size={16}/></button></div>}
        {(tab === 'Home' || tab === 'Discover') && <>
          <div className="heading-row"><div><p className="eyebrow">THE WORLD IS WATCHING</p><h1>{tab === 'Home' ? 'Your video feed' : 'Discover creators'}</h1><p className="subheading">Fresh moments. New voices. Your next favourite video.</p></div><span className="live-dot">● COMMUNITY</span></div>
          {tab === 'Discover' && <div className="searchbox"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search captions and creators"/></div>}
          <div className="feed">{filtered.map(v => <article className="video-card" key={v.id}>
            <div className="video-stage">{v.video_url ? <video src={v.video_url} controls playsInline loop /> : <div className="video-placeholder"><div className="play-circle"><Play fill="currentColor"/></div><strong>{v.demo ? 'WELCOME TO FREDRICK' : 'VIDEO'}</strong><span>{v.demo ? 'Your next favourite video is waiting.' : 'Video preview'}</span></div>}
              <div className="video-actions"><button onClick={()=>toggleLike(v.id)} className={liked[v.id]?'liked':''}><Heart fill={liked[v.id]?'currentColor':'none'}/><small>{(v.likes_count || 0) + (liked[v.id]?1:0)}</small></button><button onClick={()=>setNotice('Comments are coming in the next release.')}><MessageCircle/><small>Comment</small></button><button onClick={()=>{navigator.clipboard?.writeText(window.location.href);setNotice('FREDRICK link copied (where supported).')}}><Share2/><small>Share</small></button></div>
            </div><div className="video-meta"><b>@{v.username || 'fredrick_creator'}</b><p>{v.caption}</p></div>
          </article>)}</div>
          {!filtered.length && <div className="empty">No videos found. Try another search.</div>}
        </>}

        {tab === 'Upload' && <div className="panel"><p className="eyebrow">MAKE YOUR MOMENT</p><h1>Upload a video</h1><p className="subheading">Share your creativity with the FREDRICK community.</p>
          {!session ? <AuthBox {...{authMode,setAuthMode,email,setEmail,password,setPassword,authenticate,busy,setTab}}/> :
          <form className="upload-form" onSubmit={uploadVideo}><label className="file-drop"><input ref={fileRef} type="file" accept="video/*" onChange={e=>setUploadFile(e.target.files?.[0] || null)}/><PlusSquare size={30}/><b>{uploadFile ? uploadFile.name : 'Choose a video'}</b><span>MP4, MOV or other browser-supported video · up to 50 MB</span></label><label>Caption<textarea value={caption} onChange={e=>setCaption(e.target.value)} maxLength="300" placeholder="Tell everyone what your video is about..." /></label><button className="primary" disabled={busy}>{busy?'Uploading...':'Publish video'}</button></form>}
        </div>}

        {tab === 'Account' && <div className="panel"><p className="eyebrow">JOIN THE COMMUNITY</p><h1>{session ? 'Your account' : 'Welcome to FREDRICK'}</h1>{session ? <><p className="subheading">Signed in as {session.user.email}</p><button className="primary" onClick={logout}>Sign out</button></> : <AuthBox {...{authMode,setAuthMode,email,setEmail,password,setPassword,authenticate,busy,setTab}}/>}</div>}

        {tab === 'Profile' && <div className="panel profile-panel"><div className="profile-avatar">{session ? (session.user.email||'F')[0].toUpperCase() : 'F'}</div><p className="eyebrow">CREATOR PROFILE</p><h1>{session ? (session.user.email.split('@')[0]) : 'Your FREDRICK profile'}</h1><p className="subheading">{session ? session.user.email : 'Log in to access your creator account and publish videos.'}</p>{!session && <button className="primary" onClick={()=>setTab('Account')}>Log in or sign up</button>}</div>}
      </section>
    </main>
    <footer><span>© {new Date().getFullYear()} FREDRICK</span><span>CREATE · WATCH · SHARE</span></footer>
  </div>;
}

function NavButton({icon,label,active,onClick}) { return <button onClick={onClick} className={`nav-button ${active?'active':''}`}>{icon}<span>{label}</span></button>; }

function AuthBox({authMode,setAuthMode,email,setEmail,password,setPassword,authenticate,busy}) {
  return <form className="auth-form" onSubmit={authenticate}><label>Email address<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label><label>Password<input type="password" required minLength="6" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters"/></label><button className="primary" disabled={busy}>{busy?'Please wait...':authMode==='signup'?'Create free account':'Log in'}</button><p className="switch-auth">{authMode==='signup'?'Already have an account?':'New to FREDRICK?'} <button type="button" onClick={()=>setAuthMode(authMode==='signup'?'login':'signup')}>{authMode==='signup'?'Log in':'Sign up free'}</button></p></form>;
}