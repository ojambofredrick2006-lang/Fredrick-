# FREDRICK V1 — setup guide

This is a starter web app for FREDRICK. It includes a responsive video-feed interface, email/password sign-up and login, video upload to Supabase Storage, and a database-backed feed.

## What you need
- A GitHub account
- A free Supabase account
- A free hosting account such as Vercel or Netlify
- A computer is easiest for setup. On Android, use the browser's desktop-site option where needed.

## 1. Create the Supabase backend
1. Create a project at https://supabase.com and save its database password privately.
2. In the Supabase dashboard, open **SQL Editor** → **New query**.
3. Open `supabase/schema.sql` from this project, copy all its contents into the SQL editor and press **Run**.
4. Open **Project Settings → API** (or **Data API**) and copy the Project URL and anon/public key. Never put a `service_role` key in this website.

## 2. Add environment variables
1. Make a copy of `.env.example` and name it `.env`.
2. Put your Supabase Project URL after `VITE_SUPABASE_URL=`.
3. Put your anon/public key after `VITE_SUPABASE_ANON_KEY=`.
4. Do not upload `.env` to GitHub. The `.gitignore` file prevents that.

## 3. Run on your computer
Install Node.js (LTS), open a terminal in this folder, then run:
```bash
npm install
npm run dev
```
Open the local address printed in the terminal.

## 4. Publish free on Vercel
1. Upload this project folder to a new GitHub repository. Do not upload `.env`.
2. Sign in to https://vercel.com and choose **Add New → Project**.
3. Import your FREDRICK GitHub repository.
4. Framework preset: **Vite**. Build command: `npm run build`. Output directory: `dist`.
5. In Environment Variables, add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` with the values from Supabase.
6. Deploy. Vercel gives you a public website link.

## Important notes
- This is V1, not a complete TikTok replacement. It does not yet include persistent likes, comments, follows, messaging, notifications, live streaming, video transcoding, moderation tools or a recommendation algorithm.
- The feed currently shows the latest videos; the demo cards are placeholders when no real videos exist.
- The starter upload limit is 50 MB. Free storage and bandwidth have limits and may not be enough for a large public video platform.
- For a production public app, add reporting/moderation, rate limits, stronger upload validation, privacy controls, and review the Supabase policies before launch.
- Use email/password sign-in in this first version. Phone/SMS login needs an SMS provider and may incur charges.
