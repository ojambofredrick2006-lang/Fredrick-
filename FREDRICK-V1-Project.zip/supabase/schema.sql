-- Run this entire file in Supabase: SQL Editor > New query > Run.
create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  caption text not null default '',
  video_url text not null,
  created_at timestamptz not null default now()
);
alter table public.videos enable row level security;

create policy "Anyone can view videos" on public.videos
for select using (true);

create policy "Signed-in users can publish videos" on public.videos
for insert to authenticated with check (auth.uid() = user_id);

create policy "Owners can delete their videos" on public.videos
for delete to authenticated using (auth.uid() = user_id);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('videos', 'videos', true, 52428800, array['video/mp4','video/quicktime','video/webm'])
on conflict (id) do update set public = true, file_size_limit = 52428800;

create policy "Public can view video files" on storage.objects
for select using (bucket_id = 'videos');

create policy "Users can upload to own folder" on storage.objects
for insert to authenticated
with check (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Users can delete own video files" on storage.objects
for delete to authenticated
using (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);