# FREDRICK — Go Viral
A responsive React + Vite starter for a short-video social platform.

Start with `SETUP.md`. Configure Supabase using `supabase/schema.sql`, add environment variables, then run `npm install` and `npm run dev`.

This is an early MVP starter. Review the feature limitations and security notes in `SETUP.md` before inviting the public.